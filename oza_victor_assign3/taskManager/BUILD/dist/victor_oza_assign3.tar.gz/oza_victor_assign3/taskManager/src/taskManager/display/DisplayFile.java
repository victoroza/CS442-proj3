package taskManager.display;

public interface DisplayFile {
	/** Used to call the writers write line method
     *
     */
    public void writeToFile();
}